#include <stdio.h>
#include "alimento.h"

int main()
{
    tAlimento alimento;

    alimento = leAlimento();

    imprimeAlimento(alimento);
}